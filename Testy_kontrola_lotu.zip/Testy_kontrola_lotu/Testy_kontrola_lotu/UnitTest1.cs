namespace po_projekt_kontrola_lotu.Testy
{
    [TestFixture]
    public class PunktyTesty
    {
        [Test]
        [Description("czy miejsca punktów się zgadzają dla konstruktora domyślnego?")]
        public void KonstruktorDomyslny_PowinienTworzycPunktZOsiadaniemZero()
        {
            // Arrange
            Punkt punkt = new Punkt();

            // Assert
            Assert.AreEqual(0, punkt.getX());
            Assert.AreEqual(0, punkt.getY());
        }

        [Test]
        [Description("czy miejsca punktów się zgadzają dla konstruktora parametrowego?")]
        public void KonstruktorZParametrami_PowinienTworzycPunktZDanymiWspolrzednymi()
        {
            // Arrange
            double x = 2.5;
            double y = 3.8;
            Punkt punkt = new Punkt(x, y);

            // Assert
            Assert.AreEqual(x, punkt.getX());
            Assert.AreEqual(y, punkt.getY());
        }

        [Test]
        [Description("czy miejsca punktów się zgadzają dla konstruktora kopiującego?")]
        public void KonstruktorKopiujacy_PowinienTworzycPunktZOdpowiednimiWspolrzednymiJakoPunktPierwotny()
        {
            // Arrange
            Punkt punkt1 = new Punkt(1.2, 2.4);

            // Act
            Punkt punkt2 = new Punkt(punkt1);

            // Assert
            Assert.AreEqual(punkt1.getX(), punkt2.getX());
            Assert.AreEqual(punkt1.getY(), punkt2.getY());
        }

        [Test]
        [Description("czy miejsca punktów się zgadzają po ich przesunięciu?")]
        public void Przesun_PowinienPrzesunacPunktOWartosciachPodanychJakoOffset()
        {
            // Arrange
            Punkt punkt = new Punkt(1.0, 2.0);
            double px = 0.5;
            double py = -1.0;
            double oczekiwaneX = 1.5;
            double oczekiwaneY = 1.0;

            // Act
            punkt.przesun(px, py);

            // Assert
            Assert.AreEqual(oczekiwaneX, punkt.getX());
            Assert.AreEqual(oczekiwaneY, punkt.getY());
        }

        [Test]
        [Description("czy wyświetla oczekiwane współrzędne?")]
        public void ToString_PowinienZwrocicNapisPrzedstawiajacyWspolrzednePunktu()
        {
            // Arrange
            Punkt punkt = new Punkt(2.0, 3.0);
            string oczekiwanyNapis = "(2,3)";

            // Act
            string wynik = punkt.ToString();

            // Assert
            Assert.AreEqual(oczekiwanyNapis, wynik);
        }
    }
    [TestFixture]
    public class OdcinekTesty
    {
        [Test]
        [Description("czy punkty i wysokosc się zgadzają?")]
        public void Konstruktor_PowinienUstawicPunktyPoczatkowyiWyskosc()
        {
            // Arrange
            Punkt p1 = new Punkt(1, 2);
            double wysokosc = 10.0;

            // Act
            Odcinek odcinek = new Odcinek(p1, wysokosc, 0, 0);

            // Assert
            Assert.AreEqual(p1, odcinek.getP1());
            Assert.AreEqual(wysokosc, odcinek.getWysokosc());  
        }
        [Test]
        [Description("czy punkt P2 znajduje się we właściwym miejscu?")]
        public void Konstruktor_PowinienPrzesunacPunktP2WlasciwieNaPodstawieKierunku()
        {
            // Arrange
            Punkt p1 = new Punkt(100, 100);
            double wysokosc = 0;
            double predkosc = 10;
            double kierunek = 2;
            Punkt oczekiwanyP2v1 = new Punkt(110, 100);
            Punkt oczekiwanyP2v2 = new Punkt(100, 110);

            // Act
            Odcinek odcinek = new Odcinek(p1, wysokosc, predkosc, kierunek);

            // Assert
            Assert.IsTrue((oczekiwanyP2v1.getX() == odcinek.getP2().getX() && oczekiwanyP2v1.getY() == odcinek.getP2().getY()) || (oczekiwanyP2v2.getX() == odcinek.getP2().getX() && oczekiwanyP2v2.getY() == odcinek.getP2().getY())); 
        }

        [Test]
        [Description("czy zwraca poprawną wysokość?")]
        public void GetWysokosc_PowinienZwrocicUstawionaWysokosc()
        {
            // Arrange
            Punkt p1 = new Punkt(1.0, 2.0);
            double wysokosc = 10.0;
            double predkosc = 5.0;
            double kierunek = 3.0;

            // Act
            Odcinek odcinek = new Odcinek(p1, wysokosc, predkosc, kierunek);

            // Assert
            Assert.AreEqual(wysokosc, odcinek.getWysokosc());
        }
    }
}